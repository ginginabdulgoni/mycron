<?php $__env->startSection('title', 'Log Cronjob'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Log Cronjob: <?php echo e($cronjob->name); ?></h4>
        <form action="<?php echo e(route('cronlogs.clear', $cronjob->id)); ?>" method="POST"
            onsubmit="return confirm('Yakin ingin menghapus semua log ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger btn-sm">🗑️ Clear Logs</button>
        </form>
    </div>
    <a href="<?php echo e(route('cronjobs.index')); ?>" class="btn btn-secondary btn-sm mb-3">← Kembali ke Cronjob</a>

    <table class="table table-bordered table-striped" id="logTable">
        <thead>
            <tr>
                <th>Waktu</th>
                <th>Status</th>
                <th>Response</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cronjob->logs->sortByDesc('run_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($log->run_at)->format('d-m-Y H:i:s')); ?></td>
                    <td><?php echo e(ucfirst($log->status)); ?></td>
                    <td><?php echo e($log->response); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#logTable').DataTable({
                order: [
                    [0, 'desc']
                ],
                language: {
                    emptyTable: "Belum ada log tersedia"
                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ginginabdulgoni/developer/node/my-cron-app/laravel/resources/views/cronjobs/logs.blade.php ENDPATH**/ ?>