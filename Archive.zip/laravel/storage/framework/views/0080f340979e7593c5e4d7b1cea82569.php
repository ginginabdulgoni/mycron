<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="mb-4">Pengaturan Aplikasi</h4>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('settings.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="company_name" class="form-label">Nama Perusahaan</label>
                <input type="text" name="company_name" id="company_name" class="form-control"
                    value="<?php echo e($settings['company_name'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label for="timezone" class="form-label">Zona Waktu</label>
                <select name="timezone" id="timezone" class="form-select">
                    <?php $__currentLoopData = timezone_identifiers_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tz); ?>" <?php echo e(($settings['timezone'] ?? '') == $tz ? 'selected' : ''); ?>>
                            <?php echo e($tz); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ginginabdulgoni/developer/node/my-cron-app/laravel/resources/views/settings/index.blade.php ENDPATH**/ ?>